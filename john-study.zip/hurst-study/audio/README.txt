# Audio Files Directory

Place your MP3 audio files here.

## Naming Convention

Use simple, descriptive names that match your data.js file:
- lesson-1.mp3
- lesson-2.mp3
- lesson-3.mp3
- etc.

## How to Add Audio

1. Download your song from Suno as MP3
2. Rename the file (e.g., "lesson-4.mp3")
3. Place it in this folder
4. Reference it in data.js as: `audio_file: "/audio/lesson-4.mp3"`

## File Size

Try to keep audio files under 10MB each for faster loading.
Most 3-4 minute songs are 3-5MB.
