# Images Directory

Place your lesson images here.

## Naming Convention

Use simple, descriptive names that match your data.js file:
- lesson-1.jpg
- lesson-2.jpg
- lesson-3.png
- etc.

## Supported Formats

- JPG/JPEG
- PNG
- WEBP

## How to Add Images

1. Save or download your song artwork/lesson image
2. Rename the file (e.g., "lesson-4.jpg")
3. Place it in this folder
4. Reference it in data.js as: `image_url: "/images/lesson-4.jpg"`

## Recommendations

- Use images at least 800px wide for good quality
- Keep file sizes under 500KB if possible
- Square images (1:1 ratio) work best
